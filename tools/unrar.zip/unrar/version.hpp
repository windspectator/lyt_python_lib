#define RARVER_MAJOR     6
#define RARVER_MINOR    10
#define RARVER_BETA      0
#define RARVER_DAY      24
#define RARVER_MONTH     1
#define RARVER_YEAR   2022
